---
name: knowledge-quiz
description: Generates a 5-question quiz from a provided text file or directory to test user knowledge. Handles scope narrowing for broad topics, calculates scores, and identifies review topics.
---

# Knowledge Quiz(
"2 Overview

This skill allows the user to test their knowledge based on a specific text file or a directory of documents. It generates a 5-question quiz, evaluates the user's answers, provides a percentage score, and identifies topics that need further review.

## Workflow

### 1. Input Acquisition
To start the quiz, you must identify the source material.
- **Check Input:** Did the user provide a file path or directory?
- **If Missing:** Ask the user: "Please provide the file or directory you would like to be quizzed on."
- **Read Content:** Use available tools (like `read_file`, `list_directory`) to access the content.

### 2. Scope Assessment
Analyze the volume and breadth of the provided content.
- **Broad Content:** If the source is very large (e.g., a whole book, multiple heavy documents) or covers a wide range of disparate topics:
    - **Initiate Q&A:** Conduct a brief Q&A session (max 3 questions) to help the user narrow down the scope.
    - *Example:* "This looks like a full history book. Would you like to focus on a specific time period or region?"
- **Narrow Content:** If the content is focused, proceed directly to quiz generation.

### 3. Quiz Generation
Generate a quiz with the following constraints:
- **Quantity:** Exactly 5 questions.
- **Uniqueness:** Questions must be random and non-repetitive.
- **Relavance:** Questions must be directly answerable from the provided source material.
- **Format:** Present all 5 questions to the user in a numbered list.
- **Instruction:** Ask the user to provide their answers.

### 4. Evaluation & Reporting
Once the user provides answers:
- **Verify:** Compare user answers against the source material.
- **Score:** Calculate the percentage of correct answers (e.g., 3/5 = 60%).
- **Feedback:**
    - Provide the score.
    - List specific **topics to review** for any incorrect answers.
    - Provide the correct answers with brief explanations based on the text.